
export default function Greetings({greetings}){

    return (
        <div className="greetings">
            <h2>{greetings}</h2>
        </div>
    )
}